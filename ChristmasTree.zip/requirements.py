from os import system

system('pip install flask')
# system('python -m pip install flask') # Если не сработало - раскомментировать, предедущее - закоментировать
# system('python3 -m pip install flask') # Если не сработало - раскомментировать, предедущее - закоментировать
# system('YOUR_PYTHON_PATH/python.exe pip install flask') # Если не сработало - раскомментировать, вместо YOUR_PYTHON_PATH указать папку где находится Python, предедущее - закоментировать