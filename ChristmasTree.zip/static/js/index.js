const taskBtns = document.querySelectorAll('.task button');

taskBtns.forEach(btn => {
    btn.addEventListener('click', async function() {
        const taskId = parseInt(btn.parentNode.id, 10);

        window.location.href = `/tasks/${taskId}`;
    });
});
