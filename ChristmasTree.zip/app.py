from flask import Flask, request, session, render_template, make_response, redirect, url_for, jsonify
from databaser import Databaser
from socket import gethostname
from hashlib import sha256


app = Flask(__name__)
db = Databaser()


"""Главная"""
@app.route('/')
def index():

    try:
        cookies = request.cookies.get(gethostname())
        cookies = cookies.split(':')

        username = cookies[0]
        password = cookies[1]
    except:
        username = 'NULL'
        password = 'NULL'

    if db.fast_get_user(username, password):
        return render_template('index.html')
    else:
        return redirect(url_for('register'))

@app.route('/register')
def register():

    return render_template('register.html')
    
"""Регистрация"""
@app.route('/signup', methods=['POST'])
def signup():

    username = request.form['username']  
    password = request.form['password']

    if db.add_user(username, password):
        response = make_response(redirect(url_for('info')))    
        response.set_cookie('{}'.format(gethostname()), '{}:{}'.format(username, sha256(password.encode()).hexdigest()), max_age=30 * 24 * 60 * 60)

        session['info'] = {'val': '200', 'desc': 'Пользователь успешно зарегистрирован'}
        return response
    else:
        session['info'] = {'val': '400', 'desc': 'Пользователь с таким логином уже существует'}
        return redirect(url_for('info'))
        
"""Вход"""     
@app.route('/signin', methods=['POST'])
def signin():

    username = request.form['username']
    password = request.form['password']

    if db.get_user(username, password):
        return redirect(url_for('index'))
    else:
        session['info'] = {'val': '400', 'desc': 'Неверный логин или пароль'}
        return redirect(url_for('info'))   

"""Информация"""    
@app.route('/info')
def info():

    info = session.get('info')

    if info:
        session.pop('info')
        return render_template('info.html', info=info), int(info['val'])
    else:
        return "Ошибка", 404

"""Задания"""
@app.route('/tasks/<task_id>')
def task(task_id):
    return str(task_id)

if __name__ == '__main__':
    print('Привет! Данный сайт написан в развлекательных целях, автор(Funsy) не несет ответственность за смех! Хэппи нью э и удачного прохождения!')

    app.secret_key = 'WYAL3LHTOX3KHAO5'
    app.run()