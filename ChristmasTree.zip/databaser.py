from hashlib import sha256
import sqlite3


class Databaser:

    def __init__(self, db_name = 'database.db'):
        self.connection = sqlite3.connect(db_name, check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        self.cursor = self.connection.cursor()

        self.cursor.execute('''CREATE TABLE IF NOT EXISTS Users (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            username TEXT NOT NULL UNIQUE,
                            password TEXT NOT NULL
                            )''')

    def add_user(self, username: str, password: str) -> bool:
        try:
            self.cursor.execute('''INSERT INTO Users (username, password) VALUES (?, ?)''', (username, sha256(password.encode()).hexdigest()))
            self.connection.commit()
        except sqlite3.IntegrityError:
            return False
        
        return True

    def get_user(self, username: str, password: str) -> bool:
        self.cursor.execute('SELECT * FROM Users WHERE username = ? AND password = ?', (username, sha256(password.encode()).hexdigest()))

        return self.cursor.fetchone() is not None
    
    def fast_get_user(self, username: str, password: str) -> bool:
        self.cursor.execute('SELECT * FROM Users WHERE username = ? AND password = ?', (username, password))

        return self.cursor.fetchone() is not None